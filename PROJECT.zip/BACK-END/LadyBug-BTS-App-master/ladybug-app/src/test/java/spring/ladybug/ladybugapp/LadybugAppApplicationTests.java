package spring.ladybug.ladybugapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LadybugAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
