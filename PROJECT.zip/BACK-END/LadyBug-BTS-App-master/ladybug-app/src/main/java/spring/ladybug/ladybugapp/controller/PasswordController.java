package spring.ladybug.ladybugapp.controller;

import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import spring.ladybug.ladybugapp.pojos.Employee;
import spring.ladybug.ladybugapp.services.EmailService;
import spring.ladybug.ladybugapp.services.EmployeeService;

@CrossOrigin(origins = "*")
@RestController
public class PasswordController {

	@Autowired
	private EmployeeService employeeService;

	@Autowired
	private EmailService emailService;

	//@Autowired
	// private BCryptPasswordEncoder bCryptPasswordEncoder;

	public PasswordController() {
		// TODO Auto-generated constructor stub
	}

	// Display forgotPassword page

	// Process form submission from forgotPassword page
	@RequestMapping(value = "/forgot", method = RequestMethod.POST)
	public ResponseEntity<?> processForgotPasswordForm(@RequestBody Employee emps, HttpServletRequest request) {
		System.out.println("inside forgot");
		System.out.println(emps.getEmpEmail());
		System.out.println(request.getScheme() + " " + request.getServerName() + " " + request.getServletPath() + " "
				+ request.getServletContext());
		String email = emps.getEmpEmail();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// Lookup user in database by e-mail
		Optional<Employee> optional = employeeService.findEmployeeByEmpEmail(email);

		if (!optional.isPresent()) {
			return new ResponseEntity<Boolean>(false, HttpStatus.OK);
		} else {

			// Generate random 36-character string token for reset password
			Employee emp = optional.get();
			emp.setResetToken(UUID.randomUUID().toString());

			// Save token to database
			employeeService.save(emp);

			String appUrl = request.getScheme() + "://" + request.getServerName();

			// Email message
			SimpleMailMessage passwordResetEmail = new SimpleMailMessage();
			passwordResetEmail.setFrom("vwasekar22@gmail.com");
			passwordResetEmail.setTo(emp.getEmpEmail());
			passwordResetEmail.setSubject("Password Reset Request");
			passwordResetEmail.setText(
					"To reset your password, click the link below:\n" + appUrl + "/reset?token=" + emp.getResetToken());

			emailService.sendEmail(passwordResetEmail);

		}

		return new ResponseEntity<Boolean>(true, HttpStatus.OK);

	}

	// Process reset password form

	@RequestMapping(value = "/reset", method = RequestMethod.POST) 
	public ResponseEntity<?> setNewPassword(@RequestBody Employee emp, HttpServletRequest request, @RequestParam Map<String, String> requestParams){
	  
	  // Find the user associated with the reset token Optional<User> user =
	  Optional<Employee> employee =  employeeService.findEmployeeByResetToken(requestParams.get("token"));
	  System.out.println(employee);
	  // This should always be non-null but we check just in case if
	  if(employee.isPresent()) {
	  System.out.println(requestParams.get("token"));
	  Employee resetEmployee = employee.get();
	  System.out.println(resetEmployee.getResetToken()+" "+resetEmployee.getEmpPassword());
	  
	  System.out.println(emp.getEmpPassword());
	  // Set new password
	  System.out.println(resetEmployee.getEmpId());
	  resetEmployee.setEmpPassword(emp.getEmpPassword());
	  
	  
	  // Set the reset token to null so it cannot be used again
	  resetEmployee.setResetToken(null);
	  
	  
	  // Save user userService.saveUser(resetUser);
	  employeeService.save(resetEmployee);
	  return new ResponseEntity<Boolean>(true, HttpStatus.OK);
	  
	  }
		return new ResponseEntity<Boolean>(false, HttpStatus.OK);
	}

	// Going to reset page without a token redirects to login page

	/*
	 * @ExceptionHandler(MissingServletRequestParameterException.class) public
	 * ModelAndView handleMissingParams(MissingServletRequestParameterException ex)
	 * { return new ModelAndView("redirect:login"); }
	 */
}
