package spring.ladybug.ladybugapp.pojos;



import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "employees")
public class Employee {

	private String empId;
	private String empFirstName;
	private String empLastName;
	private String empEmail;
	private String empPassword;
	private String empRole;
	private String empUserName;
	private Employee manager;
	private Date createdOn;
	private Date lastLogin;
	private String resetToken;//private Set<Employee> subordinates = new HashSet<>();
	
	
	public Employee() {
		
	}


	public Employee(String empId, String empFirstName, String empLastName, String empEmail, String empPassword,
			String empRole, String empUserName, Employee manager,Date createdOn, Date lastLogin,
			String resetToken) {
		super();
		this.empId = empId;
		this.empFirstName = empFirstName;
		this.empLastName = empLastName;
		this.empEmail = empEmail;
		this.empPassword = empPassword;
		this.empRole = empRole;
		this.empUserName = empUserName;
		this.manager = manager;
		this.createdOn = createdOn;
		this.lastLogin = lastLogin;
		this.resetToken = resetToken;
	}


	@Id
	@Column(name="emp_id")
	public String getEmpId() {
		return empId;
	}


	public void setEmpId(String empId) {
		this.empId = empId;
	}

	@Column(name="emp_email", unique = true, nullable = false)
	public String getEmpEmail() {
		return empEmail;
	}


	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}

	@Column(name="emp_password",nullable = false)
	public String getEmpPassword() {
		return empPassword;
	}


	public void setEmpPassword(String empPassword) {
		this.empPassword = empPassword;
	}

	@Column(name="emp_role")
	public String getEmpRole() {
		return empRole;
	}


	public void setEmpRole(String empRole) {
		this.empRole = empRole;
	}

	@Column(name="emp_username")
	public String getEmpUserName() {
		return empUserName;
	}


	public void setEmpUserName(String empUserName) {
		this.empUserName = empUserName;
	}


	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "mgr_id")
	public Employee getManager() {
		return manager;
	}


	public void setManager(Employee manager) {
		this.manager = manager;	
	}
	
	@Column(name = "emp_first_name")
	public String getEmpFirstName() {
		return empFirstName;
	}


	public void setEmpFirstName(String empFirstName) {
		this.empFirstName = empFirstName;
	}

	@Column(name = "emp_last_name")
	public String getEmpLastName() {
		return empLastName;
	}


	public void setEmpLastName(String empLastName) {
		this.empLastName = empLastName;
	}

	/*
	 * @Column(name = "enabled") public boolean isEnabled() { return enabled; }
	 * 
	 * 
	 * public void setEnabled(boolean enabled) { this.enabled = enabled; }
	 */
	@Column(name = "created_on")
	public Date getCreatedOn() {
		return createdOn;
	}


	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	@Column(name = "last_login")
	public Date getLastLogin() {
		return lastLogin;
	}


	public void setLastLogin(Date lastLogin) {
		this.lastLogin = lastLogin;
	}

	@Column(name = "reset_token")
	public String getResetToken() {
		return resetToken;
	}


	public void setResetToken(String resetToken) {
		this.resetToken = resetToken;
	}


	
//	@OneToMany(mappedBy = "manager")
//	public Set<Employee> getSubordinates() {
//		return subordinates;
//	}
//
//
//	public void setSubordinates(Set<Employee> subordinates) {
//		this.subordinates = subordinates;
//	}

	
	
	
	
}
