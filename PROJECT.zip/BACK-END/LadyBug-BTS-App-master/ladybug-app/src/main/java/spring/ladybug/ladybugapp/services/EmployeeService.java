package spring.ladybug.ladybugapp.services;

import java.util.Optional;

import spring.ladybug.ladybugapp.pojos.Employee;

public interface EmployeeService {

	public Employee authenticateEmp(Employee emp);
	
	public boolean registerNewEmp(Employee emp);
	
	public Optional<Employee> findEmployeeByEmpEmail(String email);
	
    public Optional<Employee> findEmployeeByResetToken(String resetToken);
    
    public void save(Employee employee);
	
	
}
